use crate::memory::*;
use stm32f1xx_hal::prelude::*;
use stm32f1xx_hal::{pac, serial};

pub fn system_init() {
    let dp = pac::Peripherals::take().unwrap();
    let cp = pac::CorePeripherals::take().unwrap();

    let mut afio = dp.AFIO.constrain();
    let mut flash = dp.FLASH.constrain();
    let mut gpioa = dp.GPIOA.split();
    let mut gpioc = dp.GPIOC.split();

    let rcc = dp.RCC.constrain();
    let clocks = rcc.cfgr.sysclk(8_u32.MHz()).freeze(&mut flash.acr);

    let serial_config = serial::Config::default()
        .baudrate(19200_u32.bps())
        .parity_none()
        .wordlength_8bits()
        .stopbits(serial::StopBits::STOP1);
    let serial_pins = (
        /* Serial USART1 PIN: tx-a9 rx-a10 */
        gpioa.pa9.into_alternate_push_pull(&mut gpioa.crh),
        gpioa.pa10,
    );
    let serial = serial::Serial::new(
        dp.USART1,
        serial_pins,
        &mut afio.mapr,
        serial_config,
        &clocks,
    )
    .split();

    unsafe {
        /* Systerm Init && Memory Init && Panic */
        TX.write(serial.0);
        SYSDELAY.write(cp.SYST.delay(&clocks));
        PANIC_LED.write(gpioc.pc13.into_push_pull_output(&mut gpioc.crh));
    };

    {
        // /* User Code Here 🥰⬇️🤤 */
    }
}

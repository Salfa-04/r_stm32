#![no_std]
#![no_main]

mod panic_handler;
mod system_init;

use core::fmt::Write;
use cortex_m_rt::entry;
use stm32f1xx_hal::prelude::*;
use system_init::*;

#[entry]
fn entry() -> ! {
    system_init();

    let tx = unsafe { TX.assume_init_mut() };
    let timer = unsafe { SYSDELAY.assume_init_mut() };
    let mut count = 0u8;

    loop {
        writeln!(tx, "劳资蜀道山：{}", count).unwrap();
        timer.delay_ms(255_u8);
        count += 1;
    }
}

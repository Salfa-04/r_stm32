#![no_std]
#![no_main]

mod memory;
mod panic_handler;
mod system_init;

use core::fmt::Write;
use cortex_m_rt::entry;
use memory::*;
use stm32f1xx_hal::prelude::*;
use system_init::system_init;

#[entry]
fn entry() -> ! {
    system_init();

    let tx = unsafe { &mut *TX.as_mut_ptr() };
    let timer = unsafe { &mut *SYSDELAY.as_mut_ptr() };
    let mut count = 0u8;

    loop {
        writeln!(tx, "劳资蜀道山：{}", count).unwrap();
        timer.delay_ms(255_u8);
        count += 1;
    }
}

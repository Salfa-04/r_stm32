#![no_std]
#![no_main]

mod mem_init;
mod panic_handler;
mod system_init;

use core::fmt::Write;
use cortex_m_rt::entry;
use mem_init::*;
use stm32f1xx_hal::prelude::*;
use system_init::system_init;

#[entry]
fn entry() -> ! {
    system_init();

    let tx = unsafe { &mut *TX.as_mut_ptr() };
    let timer = unsafe { &mut *SYSDELAY.as_mut_ptr() };

    loop {
        writeln!(tx, "邢彦瑶: 额锤死你啊(笑脸").unwrap();
        timer.delay_ms(300_u32);
    }
}

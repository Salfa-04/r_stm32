use crate::system_init::{PANIC_LED, SYSDELAY, TX};
use core::fmt::Write;
use stm32f1xx_hal::prelude::_embedded_hal_blocking_delay_DelayMs;

#[panic_handler]
fn panic_handler(info: &core::panic::PanicInfo) -> ! {
    let led = unsafe { PANIC_LED.assume_init_mut() };
    let tx = unsafe { TX.assume_init_mut() };
    let timer = unsafe { SYSDELAY.assume_init_mut() };

    loop {
        if let Err(_) = writeln!(tx, "{}", info) {};

        led.set_low();
        timer.delay_ms(150_u8);
        led.set_high();
        timer.delay_ms(900_u16);
    }
}
